from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from app.routes import suppliers, shipments
import os

app = FastAPI(title="Supply Chain Control Copilot", version="0.1.0")

@app.get("/health")
def health():
    return {"status": "ok"}

# include routers
app.include_router(suppliers.router, prefix="/suppliers", tags=["suppliers"])
app.include_router(shipments.router, prefix="/shipments", tags=["shipments"])

from app.routes import inventory
app.include_router(inventory.router, prefix="/inventory", tags=["inventory"])\n

# Mount Gradio UI at /ui
try:
    from app.ui import build_demo
    from gradio import mount_gradio_app
    demo = build_demo()
    app = mount_gradio_app(app, demo, path="/ui")
except Exception as e:
    # If Gradio is unavailable, continue serving API only
    print("Gradio UI not mounted:", e)
