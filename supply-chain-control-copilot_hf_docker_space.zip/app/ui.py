import json
import gradio as gr
from typing import List, Dict

# Reuse internal services so UI works in mock mode too
from app.services import rag, llm_client
from app.services.agents.arcade_actions import send_email
from app.services.agents.crewai_team import run_restock_simulation

def supplier_risk_ui(supplier_name: str, question: str) -> str:
    # Build a RAG-style prompt and call LLM (mock-safe)
    chunks = rag.retrieve_chunks(question)
    prompt = rag.build_rag_prompt(question, chunks)
    _ = llm_client.generate(prompt, max_tokens=300)

    # Simple consistent response (same shape as API mock)
    top_risks = ["Port congestion", "Quality incidents"]
    recommended = ["Increase safety stock", "Dual-source critical SKUs"]
    resp = {
        "supplier_name": supplier_name,
        "risk_score": 62,
        "top_risks": top_risks,
        "recommended_actions": recommended,
        "sources": [{"type":"doc","title":c.get("title",""),"url":c.get("url","")} for c in chunks],
        "confidence": 0.78,
        "note": "Mocked scoring until MongoDB/Voyage configured"
    }
    return json.dumps(resp, indent=2)

def escalate_ui(shipment_id: str, carrier: str, expected_arrival: str) -> str:
    subject = f"SLA Breach Alert – Shipment {shipment_id} ({carrier})"
    body = f"""Hello Carrier Team,

Shipment {shipment_id} is late vs SLA. Expected arrival: {expected_arrival}.
Please confirm recovery action within 4 hours.

Thanks,
Supply Chain Control Copilot"""
    email_id = send_email("carrier@example.com", subject, body)
    resp = {
        "action_taken": "email_sent",
        "email_id": email_id,
        "next_steps": "Carrier to confirm recovery plan in 4h",
        "note": "Arcade call mocked unless ARCADE_API_KEY is set"
    }
    return json.dumps(resp, indent=2)

def restock_ui(items_json: str) -> str:
    """
    items_json example:
    [
      {"sku":"SKU-1","location":"ATL","on_hand":40,"safety_stock":60,"lead_time_days":14,"forecast_next_30d":80}
    ]
    """
    try:
        items = json.loads(items_json)
        recs, note = run_restock_simulation(items)
        resp = {"recommendations": recs, "note": note}
    except Exception as e:
        resp = {"error": str(e)}
    return json.dumps(resp, indent=2)

def build_demo():
    with gr.Blocks(title="Supply Chain Control Copilot") as demo:
        gr.Markdown("# Supply Chain Control Copilot")
        gr.Markdown("Monitor supplier risks, escalate shipment delays, and recommend inventory restocks — all in your browser.")

        with gr.Tab("Supplier Risk"):
            supplier_name = gr.Textbox(label="Supplier Name", value="Acme Parts")
            question = gr.Textbox(label="Risk Question", value="Any risks for Q3 deliveries?")
            out = gr.Code(label="Response (JSON)")
            btn = gr.Button("Analyze Risk")
            btn.click(fn=supplier_risk_ui, inputs=[supplier_name, question], outputs=out)

        with gr.Tab("Shipment Escalation"):
            shipment_id = gr.Textbox(label="Shipment ID", value="SHP-1001")
            carrier = gr.Textbox(label="Carrier", value="DHL")
            eta = gr.Textbox(label="Expected Arrival (YYYY-MM-DD)", value="2025-08-15")
            out2 = gr.Code(label="Response (JSON)")
            btn2 = gr.Button("Send Escalation Email")
            btn2.click(fn=escalate_ui, inputs=[shipment_id, carrier, eta], outputs=out2)

        with gr.Tab("Inventory Restock"):
            items = gr.Textbox(label="Items JSON", value='[{"sku":"SKU-1","location":"ATL","on_hand":40,"safety_stock":60,"lead_time_days":14,"forecast_next_30d":80}]')
            out3 = gr.Code(label="Response (JSON)")
            btn3 = gr.Button("Get Restock Recommendations")
            btn3.click(fn=restock_ui, inputs=[items], outputs=out3)

        gr.Markdown("**Tip:** This demo runs in mock mode if env keys are not set. Add `TOGETHER_API_KEY` / `FIREWORKS_API_KEY`, `MONGODB_URI`, `VOYAGE_API_KEY`, `ARCADE_API_KEY` later to switch to live services.")
    return demo
