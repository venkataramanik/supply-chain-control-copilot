# Hugging Face Spaces entrypoint (Gradio)
# This file lets you deploy the Gradio UI of Supply Chain Control Copilot to HF Spaces for free.
# It imports the same UI used in the FastAPI app and serves it standalone.
from app.ui import build_demo

demo = build_demo()

if __name__ == "__main__":
    # On Spaces, you don't need to call launch(), but keeping it for local runs.
    demo.launch()
