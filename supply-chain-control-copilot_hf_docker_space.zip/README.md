# Supply Chain Control Copilot

## Overview
**Supply Chain Control Copilot** is a **cloud-based AI assistant** that helps supply chain teams **monitor risks, detect delays, and optimize inventory** — all without running anything locally.  
It combines **LLM orchestration**, **multi-agent systems**, and **retrieval-augmented generation (RAG)** to turn raw supply chain data into **actionable decisions**.

This repo is a **full working demo** that runs in **mock mode** without keys, but can switch to live mode by adding API credentials for popular tools like **Together AI**, **Fireworks.ai**, **MongoDB Atlas Vector Search**, **Voyage AI**, **Arcade.dev**, **CrewAI**, and **LangSmith**.

---

## Why it matters
- **Proactive Supply Chain Management** — Identify supplier risks before they cause disruption.  
- **Automated Escalations** — Trigger carrier/buyer alerts without human intervention.  
- **Smarter Inventory Planning** — Predict shortages and recommend restocks using multi-agent logic.  
- **Scalable Architecture** — Works as a prototype in days, scales to production-ready with minimal changes.

---

## Key Features
1. **Supplier Risk Analysis (RAG + Orchestration)**
   - Pulls insights from contracts, scorecards, and live news feeds.  
   - Can run via **LangChain** or **LlamaIndex** pipelines.  
   - Outputs: risk score, top risks, recommended actions, and sources.

2. **Shipment Delay Detection & Escalation (Agentic AI)**
   - Compares planned vs actual shipment timelines.  
   - If late and breaching SLA, drafts and sends escalation email via **Arcade.dev**.

3. **Inventory Restock Recommendations (Multi-Agent)**
   - Uses **CrewAI** to simulate roles: Researcher, Analyst, and Action Agent.  
   - Calculates order quantities based on stock, safety stock, lead time, and forecast.

4. **Mock Mode for Instant Demo**
   - Returns realistic JSON responses even without API keys.  
   - Perfect for showing recruiters or stakeholders a live API on Day 1.

---

## Tech Stack
- **API Layer:** FastAPI + Pydantic  
- **LLM Hosting:** Together AI / Fireworks.ai  
- **Orchestration:** LangChain / LlamaIndex  
- **Vector Search (RAG):** MongoDB Atlas Vector Search  
- **Embeddings:** Voyage AI  
- **Agentic Actions:** Arcade.dev  
- **Multi-Agent:** CrewAI  
- **Monitoring:** LangSmith / Galileo  

---

## Endpoints (Full App Surface)

### Suppliers
- `POST /suppliers/risk-rag` – Supplier risk via RAG prompt (mock until DB configured)  
- `POST /suppliers/risk-langchain` – Same via LangChain (mock unless `LANGCHAIN_REAL=1`)  
- `POST /suppliers/risk-llamaindex` – Same via LlamaIndex (mock unless `LLAMAINDEX_REAL=1`)  

### Shipments
- `POST /shipments/escalate` – Delay escalation workflow with email send (mock unless `ARCADE_API_KEY` set)  

### Inventory
- `POST /inventory/restock` – Multi-agent restock simulation (mock unless `CREWAI_REAL=1`)  

---

## Environment Flags (Mock → Real Mode)

| Feature                | Env Vars Needed |
|------------------------|-----------------|
| LLM Calls              | `MODEL_PROVIDER` (`together` or `fireworks`) + API key |
| RAG                    | `MONGODB_URI`, `VOYAGE_API_KEY` |
| LangChain Pipeline     | `LANGCHAIN_REAL=1` |
| LlamaIndex Pipeline    | `LLAMAINDEX_REAL=1` |
| Email Actions          | `ARCADE_API_KEY` |
| Multi-Agent Restock    | `CREWAI_REAL=1` |
| Monitoring             | `LANGSMITH_API_KEY` |

---

## Quick Start
1. **Fork** this repo.  
2. Deploy to **Railway** or **Render** from GitHub.  
3. Without any keys, all endpoints work in mock mode.  
4. Add API keys as you go to switch to real data and actions.

---

## Deployment
- **Railway**: New Project → Deploy from GitHub → set env vars → Deploy  
- **Render**: New Web Service → GitHub → set env vars → Deploy  
- Open `/docs` for Swagger UI.

---

## License
MIT

## 🖥️ Gradio UI

In addition to the API endpoints, **Supply Chain Control Copilot** now includes a **web-based dashboard** built with [Gradio](https://www.gradio.app/).  
This makes it easy for non-technical users (and recruiters) to interact with the system.

### Accessing the UI

Once the app is running (locally, in Codespaces, or deployed to the cloud), open:

```
/ui
```

### Tabs in the UI

1. **Supplier Risk** — Analyze risks for a given supplier with a simple form.
2. **Shipment Escalation** — Trigger escalation emails to carriers when shipments breach SLA.
3. **Inventory Restock** — Upload JSON of SKUs to get restock recommendations.

### How it Works

The UI calls the same backend logic as the API:
- Runs in **mock mode** by default (no API keys needed).
- Switch to **live mode** by adding env vars for Together.ai / Fireworks.ai, MongoDB Atlas, Voyage AI, and Arcade.

### Example

**Supplier Risk Tab**  
- Enter `Acme Parts` and `Any risks for Q3 deliveries?`  
- Click **Analyze Risk**  
- JSON response with risk score, top risks, recommended actions, and sources appears.

---

## 🚀 Deploying to Hugging Face Spaces

You can deploy this project for **free** on [Hugging Face Spaces](https://huggingface.co/spaces) using the Gradio UI only.

1. Create a new Space on Hugging Face (select **Gradio** as the SDK).
2. Upload all project files (including `app.py`, `app/` folder, `requirements.txt`, and `runtime.txt`).
3. Once the Space builds, your app will be live at `https://huggingface.co/spaces/YOUR_USERNAME/YOUR_SPACE_NAME`.

The Spaces version runs the **Gradio dashboard only** — API endpoints (FastAPI) will not be active.
For full API + UI in one app, deploy to **Railway** or **Render** instead.


## 🚀 Deploy to Hugging Face Spaces (Free)

You can host the **UI** for free on Hugging Face Spaces in minutes.

### Steps
1. Go to **Hugging Face → Spaces → New Space**.
2. **Space Type:** Gradio • **Hardware:** CPU Basic (free).
3. Connect your GitHub repo or upload files.
4. Ensure the root has `app.py` (already included here) and `requirements.txt` with `gradio`.
5. Create the following **(optional)** secrets in **Settings → Variables & secrets** to enable live features:
   - `MODEL_PROVIDER` = `together` or `fireworks`
   - `TOGETHER_API_KEY` or `FIREWORKS_API_KEY`
   - `MONGODB_URI`, `VOYAGE_API_KEY`, `ARCADE_API_KEY`
6. Click **Create Space** → it will build and serve the UI at a public URL.

**Notes**
- Spaces runs the **Gradio UI only** via `app.py`. Your API endpoints (`/suppliers`, `/shipments`, `/inventory`) are part of the FastAPI app and are best hosted on Railway/Render. The UI can call external APIs if you configure it to do so.
- If you want to serve **both** API and UI from Spaces, use a **Docker Space** and run `uvicorn app.main:app`. (We can add a `Dockerfile.hf` if you want this route.)


## 🌍 Deploy Full App to Hugging Face Spaces (API + UI)

If you want **both** the FastAPI API endpoints and the Gradio UI in a **single public app**, deploy this as a **Docker Space**.

### Steps
1. Go to **Hugging Face → Spaces → New Space**.
2. **Space Type:** Docker • **Hardware:** CPU Basic (free).
3. Upload the entire repo (including `Dockerfile` and `space.yml`).
4. Wait for the build to complete — you'll get one public URL.

### Access
- `/ui` → Gradio dashboard
- `/docs` → Swagger UI for the API
- `/suppliers`, `/shipments`, `/inventory` → JSON API endpoints

### Notes
- Default is **mock mode** (no API keys required).
- Add secrets in **Settings → Variables & secrets** to enable live features.


---

## 🐳 Deploy API + UI together on **Hugging Face Docker Spaces** (One URL for everything)

This runs **FastAPI (API)** and the **Gradio UI** in the *same container*. Your Space will expose:
- `/ui` – Gradio dashboard
- `/docs` – Swagger API
- `/suppliers`, `/shipments`, `/inventory` – JSON endpoints

### Steps
1. Go to **Hugging Face → Spaces → New Space**.
2. **Space type:** `Docker` • **Hardware:** CPU Basic (free).
3. Connect your GitHub repo or upload the project files.
4. Ensure the repo contains:
   - `Dockerfile` (provided)
   - `requirements.txt`
   - `app/main.py` (FastAPI) + `app/ui.py` (Gradio UI mount)
   - `space.yaml` (metadata)
5. Create **Variables & secrets** (optional to go beyond mock mode):
   - `MODEL_PROVIDER` = `together` or `fireworks`
   - `TOGETHER_API_KEY` or `FIREWORKS_API_KEY`
   - `MONGODB_URI`, `VOYAGE_API_KEY`, `ARCADE_API_KEY`
6. Click **Create Space**. The build runs and you’ll get a public URL.
7. Open `<your-space-url>/ui` for the UI and `<your-space-url>/docs` for the API docs.
